<?php
class Categorie {
    private int $idCategorie;
    private string $nomCategorie;
    private string $description;

    public function __construct(string $nomCategorie, string $description) {
        $this->nomCategorie = $nomCategorie;
        $this->description = $description;
    }

    // GETTERS
    public function getNomCategorie() {
        return $this->nomCategorie;
    }

    public function getDescription() {
        return $this->description;
    }

    // SETTERS
    public function setNomCategorie($nomCategorie) {
        $this->nomCategorie = $nomCategorie;
    }

    public function setDescription($description) {
        $this->description = $description;
    }
}
?>
