<?php
class Article {
    private int $idArticle;
    private string $titre;
    private string $contenu;
    private string $auteur;
    private string $dateCreation;
    private int $idCategorie;
    private string $status;

    public function __construct(
        string $titre,
        string $contenu,
        string $auteur,
        string $dateCreation,
        int $idCategorie,
        string $status
    ) {
        $this->titre = $titre;
        $this->contenu = $contenu;
        $this->auteur = $auteur;
        $this->dateCreation = $dateCreation;
        $this->idCategorie = $idCategorie;
        $this->status = $status;
    }

    // GETTERS
    public function getTitre() {
        return $this->titre;
    }

    public function getContenu() {
        return $this->contenu;
    }

    public function getAuteur() {
        return $this->auteur;
    }

    public function getDateCreation() {
        return $this->dateCreation;
    }

    public function getIdCategorie() {
        return $this->idCategorie;
    }

    public function getStatus() {
        return $this->status;
    }

    // SETTERS
    public function setTitre($titre) {
        $this->titre = $titre;
    }

    public function setContenu($contenu) {
        $this->contenu = $contenu;
    }

    public function setAuteur($auteur) {
        $this->auteur = $auteur;
    }

    public function setDateCreation($dateCreation) {
        $this->dateCreation = $dateCreation;
    }

    public function setIdCategorie($idCategorie) {
        $this->idCategorie = $idCategorie;
    }

    public function setStatus($status) {
        $this->status = $status;
    }
}
?>