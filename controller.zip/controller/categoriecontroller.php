<?php
include '../config.php';

class CategorieController {

    public function addCategorie($cat) {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('INSERT INTO categorie (nomCategorie, description) VALUES (:nom, :description)');
            $req->execute([
                'nom' => $cat->getNomCategorie(),
                'description' => $cat->getDescription()
            ]);
        } catch (Exception $e) {
            die('ERROR: ' . $e->getMessage());
        }
    }

    public function listCategories() {
        $db = config::getConnexion();
        try {
            $liste = $db->query('SELECT * FROM categorie');
            return $liste->fetchAll();
        } catch (Exception $e) {
            echo 'Erreur : ' . $e->getMessage();
            return [];
        }
    }

    // ... autres méthodes
}
?>