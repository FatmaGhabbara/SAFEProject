<?php
// Chemins corrigés
include_once __DIR__ . '/../config.php';
include_once __DIR__ . '/../model/Article.php';
include_once __DIR__ . '/ArticleController.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Debug
    error_log("Données reçues: " . print_r($_POST, true));
    
    // Validation des données
    if (empty($_POST['titre']) || empty($_POST['contenu']) || empty($_POST['auteur']) || empty($_POST['dateCreation']) || empty($_POST['idCategorie'])) {
        die("Tous les champs obligatoires doivent être remplis.");
    }

    try {
        $ac = new ArticleController();

        $article = new Article(
            htmlspecialchars($_POST['titre']),
            htmlspecialchars($_POST['contenu']),
            htmlspecialchars($_POST['auteur']),
            $_POST['dateCreation'],
            intval($_POST['idCategorie']),
            "non approuvé"
        );

        if ($ac->addArticle($article)) {
            // SUCCÈS - Afficher une belle page de confirmation
            ?>
            <!DOCTYPE html>
            <html lang="fr">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Article Ajouté avec Succès</title>
                <style>
                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                    }
                    
                    body {
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 20px;
                    }
                    
                    .success-container {
                        background: white;
                        border-radius: 15px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                        padding: 40px;
                        text-align: center;
                        max-width: 500px;
                        width: 100%;
                    }
                    
                    .success-icon {
                        font-size: 80px;
                        margin-bottom: 20px;
                    }
                    
                    h1 {
                        color: #28a745;
                        margin-bottom: 15px;
                        font-size: 32px;
                    }
                    
                    .success-message {
                        color: #495057;
                        margin-bottom: 25px;
                        font-size: 18px;
                        line-height: 1.6;
                    }
                    
                    .article-preview {
                        background: #f8f9fa;
                        border-radius: 8px;
                        padding: 20px;
                        margin: 25px 0;
                        text-align: left;
                        border-left: 4px solid #28a745;
                    }
                    
                    .article-preview h3 {
                        color: #2c3e50;
                        margin-bottom: 10px;
                    }
                    
                    .article-info {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 10px;
                        margin-top: 15px;
                    }
                    
                    .info-item {
                        font-size: 14px;
                        color: #6c757d;
                    }
                    
                    .info-item strong {
                        color: #495057;
                    }
                    
                    .actions {
                        display: flex;
                        gap: 15px;
                        justify-content: center;
                        margin-top: 30px;
                        flex-wrap: wrap;
                    }
                    
                    .btn {
                        padding: 12px 25px;
                        text-decoration: none;
                        border-radius: 5px;
                        font-weight: bold;
                        transition: all 0.3s;
                        border: none;
                        cursor: pointer;
                        font-size: 16px;
                        display: inline-block;
                    }
                    
                    .btn-primary {
                        background: #28a745;
                        color: white;
                    }
                    
                    .btn-primary:hover {
                        background: #218838;
                        transform: translateY(-2px);
                    }
                    
                    .btn-secondary {
                        background: #6c757d;
                        color: white;
                    }
                    
                    .btn-secondary:hover {
                        background: #5a6268;
                        transform: translateY(-2px);
                    }
                    
                    .auto-redirect {
                        margin-top: 20px;
                        color: #6c757d;
                        font-size: 14px;
                    }
                </style>
            </head>
            <body>
                <div class="success-container">
                    <div class="success-icon">🎉</div>
                    <h1>Succès !</h1>
                    <p class="success-message">Votre article a été ajouté avec succès à la base de données.</p>
                    
                    <div class="article-preview">
                        <h3>📄 Aperçu de l'article</h3>
                        <p><strong>Titre:</strong> <?= htmlspecialchars($_POST['titre']) ?></p>
                        <p><strong>Auteur:</strong> <?= htmlspecialchars($_POST['auteur']) ?></p>
                        
                        <div class="article-info">
                            <div class="info-item">
                                <strong>📅 Date:</strong> <?= $_POST['dateCreation'] ?>
                            </div>
                            <div class="info-item">
                                <strong>📂 Catégorie:</strong> 
                                <?= ($_POST['idCategorie'] == 1) ? 'Catégorie Test 1' : 'Catégorie Test 2' ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="actions">
                        <a href="../view/backoffice/article/list.php" class="btn btn-primary">
                            📋 Voir tous les articles
                        </a>
                        <a href="../view/backoffice/article/add.php" class="btn btn-secondary">
                            ➕ Ajouter un autre article
                        </a>
                    </div>
                    
                    <div class="auto-redirect" id="countdown">
                        Redirection automatique vers la liste dans <span id="timer">5</span> secondes...
                    </div>
                </div>

                <script>
                    // Redirection automatique après 5 secondes
                    let timeLeft = 5;
                    const timerElement = document.getElementById('timer');
                    const countdown = setInterval(function() {
                        timeLeft--;
                        timerElement.textContent = timeLeft;
                        
                        if (timeLeft <= 0) {
                            clearInterval(countdown);
                            window.location.href = '../view/backoffice/article/list.php';
                        }
                    }, 1000);
                    
                    // Annuler la redirection si l'utilisateur clique sur un lien
                    document.querySelectorAll('.btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            clearInterval(countdown);
                            document.getElementById('countdown').style.display = 'none';
                        });
                    });
                </script>
            </body>
            </html>
            <?php
        } else {
            throw new Exception("Erreur lors de l'ajout dans la base de données.");
        }
    } catch (Exception $e) {
        // ERREUR
        ?>
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Erreur</title>
            <style>
                body { 
                    font-family: 'Segoe UI', sans-serif; 
                    background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
                    min-height: 100vh; 
                    display: flex; 
                    align-items: center; 
                    justify-content: center; 
                    padding: 20px; 
                    color: white;
                    text-align: center;
                }
                .error-container { 
                    background: rgba(255,255,255,0.1); 
                    padding: 40px; 
                    border-radius: 15px; 
                    backdrop-filter: blur(10px);
                    max-width: 500px;
                }
                .error-icon { font-size: 60px; margin-bottom: 20px; }
                h1 { margin-bottom: 20px; }
                .btn { 
                    display: inline-block; 
                    padding: 12px 25px; 
                    background: white; 
                    color: #ee5a24; 
                    text-decoration: none; 
                    border-radius: 5px; 
                    margin-top: 20px; 
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
            <div class="error-container">
                <div class="error-icon">❌</div>
                <h1>Erreur</h1>
                <p><?= $e->getMessage() ?></p>
                <a href="../view/backoffice/article/add.php" class="btn">↩️ Retour au formulaire</a>
            </div>
        </body>
        </html>
        <?php
    }
} else {
    header("Location: ../view/backoffice/article/add.php");
    exit();
}
?>