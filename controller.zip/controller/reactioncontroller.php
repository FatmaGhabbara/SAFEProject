<?php
include '../config.php';

class ReactionController {
    
    public function addReaction($idArticle, $reaction) {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('INSERT INTO reactions (idArticle, reaction) VALUES (:idArticle, :reaction)');
            $req->execute([
                'idArticle' => $idArticle,
                'reaction' => $reaction
            ]);
        } catch (Exception $e) {
            die('ERROR: ' . $e->getMessage());
        }
    }
}
?>