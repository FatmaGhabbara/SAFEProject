<?php
// CORRECTION DES CHEMINS DANS ArticleController.php
include_once __DIR__ . '/../config.php';
include_once __DIR__ . '/../model/Article.php';

class ArticleController {

   public function addArticle($article) {
    $db = config::getConnexion();
    try {
        $req = $db->prepare('INSERT INTO article (titre, contenu, auteur, dateCreation, idCategorie, status) VALUES (:titre, :contenu, :auteur, :dateCreation, :idCategorie, :status)');
        $req->execute([
            'titre' => $article->getTitre(),
            'contenu' => $article->getContenu(),
            'auteur' => $article->getAuteur(),
            'dateCreation' => $article->getDateCreation(),
            'idCategorie' => $article->getIdCategorie(),
            'status' => $article->getStatus()
        ]);
        return true;
    } catch (Exception $e) {
        error_log("Erreur addArticle: " . $e->getMessage());
        return false;
    }
}

    public function handleAddArticle() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (empty($_POST['titre']) || empty($_POST['contenu']) || empty($_POST['auteur']) || empty($_POST['dateCreation']) || empty($_POST['idCategorie'])) {
                die("Tous les champs obligatoires doivent être remplis.");
            }

            $article = new Article(
                htmlspecialchars($_POST['titre']),
                htmlspecialchars($_POST['contenu']),
                htmlspecialchars($_POST['auteur']),
                $_POST['dateCreation'],
                intval($_POST['idCategorie']),
                "non approuvé"
            );

            if ($this->addArticle($article)) {
                header("Location: ../view/backoffice/article/list.php");
                exit();
            } else {
                die("Erreur lors de l'ajout de l'article.");
            }
        }
    }

    public function listArticles() {
        $db = config::getConnexion();
        try {
            $liste = $db->query('SELECT * FROM article');
            return $liste->fetchAll();
        } catch (Exception $e) {
            echo 'Erreur : ' . $e->getMessage();
            return [];
        }
    }

   public function deleteArticle($id) {
    $db = config::getConnexion();
    try {
        $req = $db->prepare('DELETE FROM article WHERE idArticle = :id');
        $req->execute(['id' => $id]);
        return true;
    } catch (Exception $e) {
        die('Error: ' . $e->getMessage());
    }
}

    public function updateArticle($id, $article) {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('UPDATE article SET titre=:t, contenu=:c, auteur=:a, dateCreation=:d, idCategorie=:cat, status=:s WHERE idArticle=:id');
            $req->execute([
                'id' => $id,
                't' => $article->getTitre(),
                'c' => $article->getContenu(),
                'a' => $article->getAuteur(),
                'd' => $article->getDateCreation(),
                'cat' => $article->getIdCategorie(),
                's' => $article->getStatus()
            ]);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    public function getArticle($id) {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('SELECT * FROM article WHERE idArticle = :id');
            $req->execute(['id' => $id]);
            return $req->fetch();
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
    
    public function approveArticle($id){
        $db = config::getConnexion();
        try{
            $req = $db->prepare("UPDATE article SET status='approved' WHERE idArticle=:id");
            $req->execute(['id'=>$id]);
        }catch(Exception $e){
            die('Error:'. $e->getMessage());
        }
    }

    public function searchArticle($keyword) {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('SELECT * FROM article WHERE titre LIKE :keyword OR contenu LIKE :keyword');
            $req->execute(['keyword' => '%'.$keyword.'%']);
            return $req->fetchAll();
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    public function articlesByCategorie($idCategorie) {
        $db = config::getConnexion();
        try {
            $req = $db->prepare('SELECT * FROM article WHERE idCategorie = :id');
            $req->execute(['id' => $idCategorie]);
            return $req->fetchAll();
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
  public function getArticleById($id) {
    $db = config::getConnexion();
    try {
        $req = $db->prepare('SELECT * FROM article WHERE idArticle = :id');
        $req->execute(['id' => $id]);
        return $req->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Erreur getArticleById: " . $e->getMessage());
        return false;
    }
}
public function disapproveArticle($id){
    $db = config::getConnexion();
    try{
        $req = $db->prepare("UPDATE article SET status='pending' WHERE idArticle=:id");
        $req->execute(['id'=>$id]);
        return true;
    }catch(Exception $e){
        error_log("Erreur disapproveArticle: " . $e->getMessage());
        return false;
    }
}
public function listApprovedArticles() {
    $db = config::getConnexion();
    try {
        $req = $db->prepare('SELECT * FROM article WHERE status = "approved" ORDER BY dateCreation DESC');
        $req->execute();
        return $req->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log('Erreur listApprovedArticles: ' . $e->getMessage());
        return [];
    }
}

// Méthode pour ajouter une réaction
public function addReaction($article_id, $user_ip) {
    $db = config::getConnexion();
    try {
        // Vérifier si l'utilisateur a déjà réagi
        $checkReq = $db->prepare('SELECT id FROM article_reactions WHERE article_id = :article_id AND user_ip = :user_ip');
        $checkReq->execute([
            'article_id' => $article_id,
            'user_ip' => $user_ip
        ]);
        
        if ($checkReq->fetch()) {
            return false; // Déjà réagi
        }
        
        // Ajouter la réaction
        $req = $db->prepare('INSERT INTO article_reactions (article_id, user_ip) VALUES (:article_id, :user_ip)');
        $req->execute([
            'article_id' => $article_id,
            'user_ip' => $user_ip
        ]);
        return true;
    } catch (Exception $e) {
        error_log("Erreur addReaction: " . $e->getMessage());
        return false;
    }
}

// Méthode pour compter les réactions d'un article
public function getReactionsCount($article_id) {
    $db = config::getConnexion();
    try {
        $req = $db->prepare('SELECT COUNT(*) as count FROM article_reactions WHERE article_id = :article_id');
        $req->execute(['article_id' => $article_id]);
        $result = $req->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        error_log("Erreur getReactionsCount: " . $e->getMessage());
        return 0;
    }
}

// Méthode pour vérifier si l'utilisateur a déjà réagi
public function hasUserReacted($article_id, $user_ip) {
    $db = config::getConnexion();
    try {
        $req = $db->prepare('SELECT id FROM article_reactions WHERE article_id = :article_id AND user_ip = :user_ip');
        $req->execute([
            'article_id' => $article_id,
            'user_ip' => $user_ip
        ]);
        return $req->fetch() !== false;
    } catch (Exception $e) {
        error_log("Erreur hasUserReacted: " . $e->getMessage());
        return false;
    }
}

// Méthode pour avoir le compte de réactions pour tous les articles (backoffice)
public function getArticlesWithReactions() {
    $db = config::getConnexion();
    try {
        $sql = 'SELECT a.*, COUNT(ar.id) as reactions_count 
                FROM article a 
                LEFT JOIN article_reactions ar ON a.idArticle = ar.article_id 
                GROUP BY a.idArticle 
                ORDER BY a.dateCreation DESC';
        $req = $db->query($sql);
        return $req->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Erreur getArticlesWithReactions: " . $e->getMessage());
        return [];
    }
}
}

// Gestion des actions
if (isset($_GET['action'])) {
    $ac = new ArticleController();
    switch ($_GET['action']) {
        case 'add':
            $ac->handleAddArticle();
            break;
    }
}
?>